let input = check_limit("Enter a maximum number:");

generateNum(input);