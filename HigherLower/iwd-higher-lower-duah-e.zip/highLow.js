let genNum = Math.floor(Math.random() * 20) + 1;

function checkGuess() {
    let userGuess = Number(document.getElementById("numberInput").value);
    let div = document.querySelector(".container");
    let pToReplace = div.getElementsByTagName("p")[0];
    let displayResults = document.createElement("p");
    console.log(userGuess);
    console.log(genNum);
    if(userGuess == genNum){
        displayResults.innerHTML = "You got it!";
        div.replaceChild(displayResults, pToReplace);
    }
    else if(userGuess < genNum) {
        displayResults.innerHTML = "No, try a higher number.";
        div.replaceChild(displayResults, pToReplace);
    }
    else if(userGuess > genNum) {
        displayResults.innerHTML = "No, try a lower number.";
        div.replaceChild(displayResults, pToReplace);
    }
}


